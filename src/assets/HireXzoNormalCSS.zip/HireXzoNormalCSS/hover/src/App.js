import './App.css';
import NavBar from './components/NavBar';
import HoverCard from './components/HoverCard';
import { useState } from 'react';

function App() {

  const [open, setOpen] = useState(false);

  const onClickHandler = ()=>{
    setOpen(!open);
  }


  return (
    <div className='App'>
        <NavBar onClickHandler={onClickHandler}/>
        <div>
          {
            open?(<HoverCard/>):null
          }
        </div>
    </div>
  );
}

export default App;