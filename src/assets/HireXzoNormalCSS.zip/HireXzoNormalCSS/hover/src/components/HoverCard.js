import React from 'react';
import './HoverCard.css';
import { FaChevronRight } from "react-icons/fa";

const HoverCard = () => {
  return (
    <div className='hover-card'>
      <div className='main-font'>Get Courses</div>

      <div className='card-container'>
        <div className='course-container'>
          <div className='card-title'>
            <span className='course-name'>AI & ML Course</span>
            <span className='chevron'><FaChevronRight /></span>
          </div>
          <div>Your Future Starts Here!</div>
        </div>

        {/* Repeat the above block for other items as needed */}
        <div className='course-container'>
          <div className='card-title'>
            <span className='course-name'>AI & ML Course</span>
            <span className='chevron'><FaChevronRight /></span>
          </div>
          <div>Your Future Starts Here!</div>
        </div>

        <div className='course-container'>
          <div className='card-title'>
            <span className='course-name'>AI & ML Course</span>
            <span className='chevron'><FaChevronRight /></span>
          </div>
          <div>Your Future Starts Here!</div>
        </div>

        <div className='course-container'>
          <div className='card-title'>
            <span className='course-name'>AI & ML Course</span>
            <span className='chevron'><FaChevronRight /></span>
          </div>
          <div>Your Future Starts Here!</div>
        </div>

    
      </div>
    </div>
  );
}

export default HoverCard;
