import React from 'react';
import './NavBar.css';

const Navbar = ({ onClickHandler }) => {
  return (
    <div className="navbar">
      <ul className="nav-list">
        <li className="nav-items" onClick={() => onClickHandler()}>
          <div className='nav-item'>
            Courses
            <div className="indicator"></div>
          </div>
        </li>
        <li>Jobs</li>
        <li>Posts</li>
        <li>Assessments</li>
        <li>Login</li>
        <li>Host</li>
      </ul>
    </div>
  );
}

export default Navbar;
